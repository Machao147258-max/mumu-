﻿#!/system/bin/sh
# 安全模式：仅修改 ro.serialno
# 移除了 ril.serialnumber 等属性，防止干扰模拟器的网络/基带服务导致卡死
resetprop ro.serialno 865146042407069