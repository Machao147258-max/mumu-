#!/system/bin/sh
# Fix Board and Hardware
resetprop ro.board.platform kona
resetprop ro.hardware qcom
resetprop ro.product.device munch
