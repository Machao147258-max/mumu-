#!/system/bin/sh
# Fix Fingerprint
resetprop ro.build.fingerprint Redmi/munch/munch:12/SKQ1.211006.001/V13.0.5.0.SLMCNXM:user/release-keys
resetprop ro.system.build.fingerprint Redmi/munch/munch:12/SKQ1.211006.001/V13.0.5.0.SLMCNXM:user/release-keys
resetprop ro.vendor.build.fingerprint Redmi/munch/munch:12/SKQ1.211006.001/V13.0.5.0.SLMCNXM:user/release-keys
resetprop ro.build.description munch-user 12 SKQ1.211006.001 V13.0.5.0.SLMCNXM release-keys
resetprop ro.build.version.security_patch 2022-05-01
